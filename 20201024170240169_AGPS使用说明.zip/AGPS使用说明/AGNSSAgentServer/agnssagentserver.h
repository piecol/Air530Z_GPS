#ifndef AGNSSAGENTSERVER_H
#define AGNSSAGENTSERVER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

#define CASIC

#ifdef CASIC
#define EPH_BANNER "CASIC"
#define EPH_SERVER "www.gnss-aide.com"
#define EPH_PORT 2621
#define EPH_REQUEST "user=%s;pwd=%s;cmd=eph;lat=0.0;lon=0.0;"
#define USERNAME "freetrial"
#define PASSWORD "123456"
#define EPH_KEY_BYTE 0xBA
#define EPH_LENGTH_FLAG "DataLength"
#define AID_INI_SIZE 66
#else
#define EPH_BANNER "U-BLOX"
#define EPH_SERVER "agps.u-blox.com"
#define EPH_PORT 46434
#define EPH_REQUEST "user=%s;pwd=%s;cmd=ephfull;lat=0.0;lon=0.0\n"
#define USERNAME "ublox-account"
#define PASSWORD "ublox-password"
#define EPH_KEY_BYTE 0xB5
#define EPH_LENGTH_FLAG "Content-Length"
#define AID_INI_SIZE 56
#endif

#define PORT 313
#define EPH_UPDATE_INTERVAL 1800 // seconds
#define EPH_EXPIRED_SECONDS 7200 // seconds

typedef enum {
    CMD = 0,
    LAT = 1,
    LON = 2,
    MAX_MASK,
}CLIENT_MESSAGE_MASK;

typedef enum {
    EPH = 0x1,
    AID = 0x2,
    FULL = EPH | AID,
}CLIENT_MESSAGE_CMD;

typedef struct {
    int cmd;
    double lat;
    double lon;
    bool mask[MAX_MASK];
}CLIENT_MESSAGE;

class AGnssAgentServer : public QObject
{
    Q_OBJECT
public:
    explicit AGnssAgentServer(QObject *parent = 0);
    void start();

protected:
    virtual void timerEvent(QTimerEvent *event);

signals:

private slots:
    void onAgnssConnection();
    void onClientMessage();
    void ephConnected();
    void ephReadyRead();

private:
    QByteArray packReplyMessage(QByteArray message);
    QByteArray packPayload(CLIENT_MESSAGE msg);
    void unpackClientMessage(QByteArray message, CLIENT_MESSAGE *pMsg);
    QByteArray packCurrentAidIniMessage(double lat, double lon);
    void getEphDataFromServer();
    bool checkEphDataLength(QByteArray data);
    int getEphDataLength(QByteArray data);
    int countEphDataLength(QByteArray data);
    bool ephExpired();


private:
    QTcpServer *server;
    QTcpSocket *ephSocket;
    QByteArray ephData;
    int ephTimerId;
    QByteArray tempEphData;
    qint64 ephTimeStamp;
};

#endif // AGNSSAGENTSERVER_H
