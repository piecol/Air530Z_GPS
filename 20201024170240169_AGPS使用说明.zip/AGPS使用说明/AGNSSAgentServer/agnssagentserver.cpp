#include "agnssagentserver.h"
#include <QDebug>
#include <QDateTime>
#include <QTimerEvent>
#ifdef CASIC
#include "casicAgnssAidIni.c"
#else
#include "ubloxAgnssAidIni.c"
#endif

AGnssAgentServer::AGnssAgentServer(QObject *parent) : QObject(parent)
{
    server = new QTcpServer;
    connect(server, SIGNAL(newConnection()), this, SLOT(onAgnssConnection()));

    ephSocket = new QTcpSocket;
    connect(ephSocket, SIGNAL(connected()), this, SLOT(ephConnected()));
    connect(ephSocket, SIGNAL(readyRead()), this, SLOT(ephReadyRead()));

    ephTimerId = startTimer(EPH_UPDATE_INTERVAL * 1000);

    ephTimeStamp = 0;
}

void AGnssAgentServer::start()
{
    qDebug()<<"AGnss server start, listen port: "<<PORT;
    qDebug()<<"EPH data source:"<<EPH_BANNER;
    qDebug()<<"-------------------------------------------------";
    qDebug()<<"Accept message formats:";
    qDebug()<<"cmd=?; '?' must be one of 'full', 'eph', 'aid'.";
    qDebug()<<"lat=?; '?' must be a float number.";
    qDebug()<<"lon=?; '?' must be a float number.";
    qDebug()<<"For example: 'cmd=full;lat=39.12;lon=114.21;'";
    qDebug()<<"-------------------------------------------------";
    server->listen(QHostAddress::Any, PORT);
    getEphDataFromServer();
}

void AGnssAgentServer::timerEvent(QTimerEvent *event)
{
    if (event->timerId() == ephTimerId) {
        getEphDataFromServer();
    }
}

void AGnssAgentServer::onAgnssConnection()
{
    QTcpSocket *client = server->nextPendingConnection();
    qDebug()<<"New connection established: "<<client->peerAddress();
    connect(client, SIGNAL(readyRead()), this, SLOT(onClientMessage()));
    connect(client, SIGNAL(disconnected()), client, SLOT(deleteLater()));
}

void AGnssAgentServer::onClientMessage()
{
    QTcpSocket *client = (QTcpSocket*)sender();
    QByteArray message = client->readAll();
    qDebug()<<"Client:"<<client->peerAddress();
    qDebug()<<"Message:"<<message;

    QByteArray reply = packReplyMessage(message);
    client->write(reply);
    qDebug()<<"Reply"<<reply.count()<<"bytes to client.";
    client->disconnectFromHost();
    qDebug()<<"Close connection!\n";
}

void AGnssAgentServer::ephConnected()
{
    tempEphData.clear();
    qDebug()<<"AGNSS server connected.";

    qDebug()<<"******************************************";
    qDebug()<<"User:"<<USERNAME<<"Password:"<<PASSWORD;
#ifdef CASIC
    if (strcmp(USERNAME, "freetrial") == 0) {
        qDebug()<<"WARNING: THIS IS A freetrial ACCOUNT!!!";
    }
#endif
    qDebug()<<"******************************************";

    char request[128];
    sprintf(request, EPH_REQUEST, USERNAME, PASSWORD);

    ephSocket->write(request);
    qDebug()<<"Request message:"<<request;
}

void AGnssAgentServer::ephReadyRead()
{
    QByteArray d = ephSocket->readAll();
    qDebug()<<"Received"<<d.count()<<"bytes eph data from server.";
    qDebug()<<"Data:"<<d.left(128)<<"...";
    tempEphData.append(d);
    if (checkEphDataLength(tempEphData)) {
        ephData.clear();
        bool flag = false;
        foreach(uchar ch, tempEphData) {
            if (ch == EPH_KEY_BYTE) {
                flag = true;
            }
            if (flag == true) {
                ephData.append(ch);
            }
        }
        ephTimeStamp = QDateTime::currentMSecsSinceEpoch() / 1000;
        qDebug()<<"EPH data updated!\n";

        tempEphData.clear();
    }
}

QByteArray AGnssAgentServer::packReplyMessage(QByteArray clientMessage)
{
    CLIENT_MESSAGE msg;
    unpackClientMessage(clientMessage, &msg);

    QByteArray payload = packPayload(msg);
    qDebug("Payload length = %d bytes", payload.length());

    QByteArray reply;
    reply.append(QString("%1 AGNSS agent server.\n").arg(EPH_BANNER));
    reply.append(QString("%1: %2.\n").arg(EPH_LENGTH_FLAG).arg(payload.length()));
    reply.append("\n");
    reply.append(payload);
    return reply;
}

QByteArray AGnssAgentServer::packPayload(CLIENT_MESSAGE msg)
{
    if (!msg.mask[CMD]) {
        return QByteArray("Missing or invalid \"cmd=?;\".");
    }

    if (!msg.mask[LON]) {
        return QByteArray("Missing or invalid \"lon=?;\".");
    }
    if (!msg.mask[LAT]) {
        return QByteArray("Missing or invalid \"lat=?;\".");
    }

    QByteArray payload;
    if (msg.cmd & AID) {
        QByteArray aidIniMessage = packCurrentAidIniMessage(msg.lat, msg.lon);
        qDebug()<<"Add AID INI message";
        payload.append(aidIniMessage);
    }

    if (msg.cmd & EPH) {
        qDebug()<<"Add EPH messages.";
        if (ephExpired()) {
            qDebug()<<"WARNING: Eph data expired!!!";
        }
        else {
            payload.append(ephData);
        }
    }
    return payload;
}

void AGnssAgentServer::unpackClientMessage(QByteArray message, CLIENT_MESSAGE *pMsg)
{
    // message: "lat=34.123412;lon=114.219213;"
    QByteArrayList tokenList = message.toLower().split(';');
    foreach(QByteArray token, tokenList) {
        QByteArrayList keyAndValue = token.split('=');
        if (keyAndValue.count() == 2) {
            QByteArray key = keyAndValue.at(0);
            QByteArray value = keyAndValue.at(1);
            bool ok;
            if (key == "cmd") {
                if (value == "full") {
                    pMsg->cmd = FULL;
                    pMsg->mask[CMD] = true;
                }
                else if (value == "eph") {
                    pMsg->cmd = EPH;
                    pMsg->mask[CMD] = true;
                }
                else if (value == "aid") {
                    pMsg->cmd = AID;
                    pMsg->mask[CMD] = true;
                }
                else {
                    qDebug()<<"WARNING: invalid cmd:"<<value;
                }
            }
            else if (key == "lat") {
                pMsg->lat = value.toDouble(&ok);
                if (!ok) {
                    qDebug()<<"WARNING: invalid lat:"<<value;
                }
                pMsg->mask[LAT] = ok;
            }
            else if (key == "lon") {
                pMsg->lon = value.toDouble(&ok);
                if (!ok) {
                    qDebug()<<"WARNING: invalid lon:"<<value;
                }
                pMsg->mask[LON] = ok;
            }
        }
    }
}

QByteArray AGnssAgentServer::packCurrentAidIniMessage(double lat, double lon)
{
    DATETIME_STR datetime;
    QDateTime dt = QDateTime::currentDateTimeUtc();
    datetime.year = dt.date().year();
    datetime.month = dt.date().month();
    datetime.day = dt.date().day();
    datetime.hour = dt.time().hour();
    datetime.minute = dt.time().minute();
    datetime.second = dt.time().second();
    datetime.ms = (float)dt.time().msec();
    datetime.valid = 1;

    POS_LLA_STR lla;
    lla.alt = 0.0;
    lla.lat = lat;
    lla.lon = lon;
    lla.valid = 1;

    qDebug("DATETIME: valid=%d, date=%d-%02d-%02d, time=%02d:%02d:%02d, ms=%f",
           datetime.valid,
           datetime.year, datetime.month, datetime.day,
           datetime.hour, datetime.minute, datetime.second, datetime.ms);
    qDebug("LLA:      valid=%d, lat=%f, lon=%f, alt=%f", lla.valid, lla.lat, lla.lon, lla.alt);

    qDebug("Pack %s AID INI Message.", EPH_BANNER);

    char aidIniMsg[AID_INI_SIZE];
    memset(aidIniMsg, 0, AID_INI_SIZE);
#ifdef CASIC
    casicAgnssAidIni(datetime, lla, aidIniMsg);
#else
    ubloxAgnssAidIni(datetime, lla, aidIniMsg);
#endif
    return QByteArray(aidIniMsg, AID_INI_SIZE);
}

void AGnssAgentServer::getEphDataFromServer()
{
    qDebug()<<"Start update EPH data.";
    qDebug()<<"Try to connect to server:"<<EPH_SERVER<<":"<<EPH_PORT;
    if (ephSocket->state() != QTcpSocket::UnconnectedState) {
        ephSocket->abort();
        qDebug()<<"Eph socket: Abort!";
    }
    ephSocket->connectToHost(EPH_SERVER, EPH_PORT);
}

bool AGnssAgentServer::checkEphDataLength(QByteArray data)
{
    qDebug()<<"Check EPH data";
    int n = getEphDataLength(data);
    qDebug()<<"Get EPH data length:"<<n;
    if (n == 0) {
        return false;
    }
    int counter = countEphDataLength(data);
    qDebug()<<"Count EPH data length:"<<counter;
    if (counter == 0) {
        return false;
    }
    if (counter == n) {
        qDebug()<<"EPH data length check passed.";
        return true;
    }
    else {
        if (n > counter) {
            qDebug()<<"Wait for more EPH data.";
        }
        else {
            qDebug()<<"EPH data length unmatched:"<<n<<counter;
        }
    }
    return false;
}

int AGnssAgentServer::getEphDataLength(QByteArray data)
{
    QByteArrayList lineList = data.split('\n');
    if (lineList.count() > 2) {
        QByteArray lengthLine = lineList.at(1);
        if (lengthLine.startsWith(EPH_LENGTH_FLAG)){
            int n = 0;
            foreach(char c, lengthLine) {
                if (c >= '0' && c <= '9') {
                    n = n * 10 + c - '0';
                }
            }
            return n;
        }
    }
    return 0;
}

int AGnssAgentServer::countEphDataLength(QByteArray data)
{
    int counter = 0;
    bool startCount = false;
    foreach(uchar b, data) {
        if (b == EPH_KEY_BYTE) {
            startCount = true;
        }
        if (startCount) {
            counter += 1;
        }
    }
    return counter;
}

bool AGnssAgentServer::ephExpired()
{
    qint64 timestamp = QDateTime::currentMSecsSinceEpoch() / 1000;
    return timestamp - ephTimeStamp > EPH_EXPIRED_SECONDS;
}
